package smartstudyplanner;

import java.time.LocalDate;
import java.util.*;

public class PlannerCLI {

    private static final Scanner sc = new Scanner(System.in);
    private static final List<Task> tasks = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("Smart Study Planner (Java) - CLI\n");

        while (true) {
            System.out.println("Commands: add | list | schedule | sample | exit");
            System.out.print("> ");
            String cmd = sc.nextLine().trim().toLowerCase();

            try {
                switch (cmd) {
                    case "add": addTask(); break;
                    case "list": listTasks(); break;
                    case "schedule": schedule(); break;
                    case "sample": sample(); break;
                    case "exit": return;
                    default: System.out.println("Unknown command");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
    }

    static void addTask() {
        System.out.print("Title: ");
        String title = sc.nextLine();

        System.out.print("Deadline (YYYY-MM-DD or blank): ");
        String d = sc.nextLine().trim();
        LocalDate deadline = d.isEmpty() ? null : LocalDate.parse(d);

        System.out.print("Difficulty (1-5): ");
        int diff = Integer.parseInt(sc.nextLine());

        System.out.print("Hours required: ");
        double hours = Double.parseDouble(sc.nextLine());

        Task t = new Task(title, deadline, diff, hours);
        tasks.add(t);
        System.out.println("Added: " + t);
    }

    static void listTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks");
            return;
        }
        for (int i = 0; i < tasks.size(); i++)
            System.out.println((i + 1) + ". " + tasks.get(i));
    }

    static void schedule() {
        System.out.print("Hours per day: ");
        int hours = Integer.parseInt(sc.nextLine());

        System.out.print("Days to plan: ");
        int days = Integer.parseInt(sc.nextLine());

        var plan = Scheduler.makeDailyPlan(tasks, LocalDate.now(), hours, days);

        System.out.println("\nPLAN:\n");
        System.out.println(Scheduler.planSummary(plan));
    }

    static void sample() {
        tasks.add(new Task("Finish DSA notes", LocalDate.now().plusDays(3), 4, 3));
        tasks.add(new Task("Practice Java OOP", LocalDate.now().plusDays(7), 5, 5));
        tasks.add(new Task("Read paper", LocalDate.now().plusDays(14), 3, 2));
        System.out.println("Sample tasks added.");
    }
}

package smartstudyplanner;

import java.time.LocalDate;
import java.util.*;

public class Scheduler {

    public static class Slot {
        public final Task task;
        public final double hours;

        public Slot(Task task, double hours) {
            this.task = task;
            this.hours = hours;
        }

        public String toString() {
            return task.getTitle() + " (" + hours + "h)";
        }
    }

    public static Map<LocalDate, List<Slot>> makeDailyPlan(
            List<Task> tasks, LocalDate start, int hoursPerDay, int horizonDays) {

        Map<LocalDate, List<Slot>> plan = new TreeMap<>();
        for (int i = 0; i < horizonDays; i++)
            plan.put(start.plusDays(i), new ArrayList<>());

        List<Task> sorted = new ArrayList<>(tasks);
        sorted.sort((a, b) -> Double.compare(
                b.priorityScore(start),
                a.priorityScore(start)
        ));

        for (Task t : sorted) {
            double remaining = t.getEstHours();
            int lastIndex = horizonDays - 1;

            if (t.getDeadline() != null) {
                long daysToDeadline = java.time.temporal.ChronoUnit.DAYS.between(start, t.getDeadline());
                lastIndex = (int) Math.min(horizonDays - 1, Math.max(0, daysToDeadline));
            }

            for (int i = 0; i <= lastIndex && remaining > 0; i++) {
                LocalDate day = start.plusDays(i);
                double used = plan.get(day).stream().mapToDouble(s -> s.hours).sum();
                double free = hoursPerDay - used;
                if (free <= 0) continue;

                double take = Math.min(free, remaining);
                plan.get(day).add(new Slot(t, take));
                remaining -= take;
            }

            for (int i = lastIndex + 1; i < horizonDays && remaining > 0; i++) {
                LocalDate day = start.plusDays(i);
                double used = plan.get(day).stream().mapToDouble(s -> s.hours).sum();
                double free = hoursPerDay - used;

                if (free <= 0) continue;

                double take = Math.min(free, remaining);
                plan.get(day).add(new Slot(t, take));
                remaining -= take;
            }
        }

        return plan;
    }

    public static String planSummary(Map<LocalDate, List<Slot>> plan) {
        StringBuilder sb = new StringBuilder();
        for (var e : plan.entrySet()) {
            sb.append(e.getKey()).append("\n");
            if (e.getValue().isEmpty())
                sb.append("  (no tasks)\n");
            else {
                Map<String, Double> bucket = new LinkedHashMap<>();
                for (Slot s : e.getValue())
                    bucket.merge(s.task.getTitle(), s.hours, Double::sum);
                for (var t : bucket.entrySet())
                    sb.append("  - ").append(t.getKey()).append(": ").append(t.getValue()).append("h\n");
            }
        }
        return sb.toString();
    }
}


package smartstudyplanner;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class Task implements java.io.Serializable {
    private final String id;
    private String title;
    private LocalDate deadline; 
    private int difficulty; 
    private double estHours;
    private LocalDate createdAt;

    public Task(String title, LocalDate deadline, int difficulty, double estHours) {
        this.id = UUID.randomUUID().toString();
        this.title = title;
        this.deadline = deadline;
        this.difficulty = Math.max(1, Math.min(5, difficulty));
        this.estHours = Math.max(0.1, estHours);
        this.createdAt = LocalDate.now();
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public LocalDate getDeadline() { return deadline; }
    public int getDifficulty() { return difficulty; }
    public double getEstHours() { return estHours; }

    public void setTitle(String title) { this.title = title; }
    public void setDeadline(LocalDate d) { this.deadline = d; }
    public void setDifficulty(int d) { this.difficulty = d; }
    public void setEstHours(double h) { this.estHours = h; }

    public double priorityScore(LocalDate fromDate) {
        double score = 0.0;

        if (deadline != null) {
            long daysLeft = java.time.temporal.ChronoUnit.DAYS.between(fromDate, deadline);
            score += Math.max(0, (30.0 - daysLeft) / 30.0) * 50.0;
        } else score += 5.0;

        score += (difficulty / 5.0) * 30.0;

        score += Math.max(0, (2.0 - Math.min(estHours, 10.0)) / 2.0) * 15.0;

        return score;
    }

    @Override
    public String toString() {
        DateTimeFormatter f = DateTimeFormatter.ISO_LOCAL_DATE;
        return String.format("[%s] %s | deadline: %s | diff: %d | est: %.1fh",
                id.substring(0, 8), title,
                deadline == null ? "-" : deadline.format(f),
                difficulty, estHours);
    }
}

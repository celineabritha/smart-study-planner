package smartstudyplanner;

import java.io.*;
import java.time.LocalDate;
import java.util.*;

public class Storage {

    public static void saveCsv(List<Task> tasks, String path) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(path))) {
            out.println("id,title,deadline,difficulty,estHours,createdAt");
            for (Task t : tasks) {
                out.printf("%s,%s,%s,%d,%.2f,%s\n",
                        t.getId(),
                        t.getTitle().replace(",", ";"),
                        t.getDeadline() == null ? "" : t.getDeadline(),
                        t.getDifficulty(),
                        t.getEstHours(),
                        t.getDeadline());
            }
        }
    }

    public static List<Task> loadCsv(String path) throws IOException {
        List<Task> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",", -1);
                String title = p[1].replace(";", ",");
                LocalDate deadline = p[2].isEmpty() ? null : LocalDate.parse(p[2]);
                int diff = Integer.parseInt(p[3]);
                double est = Double.parseDouble(p[4]);
                list.add(new Task(title, deadline, diff, est));
            }
        }
        return list;
    }
}

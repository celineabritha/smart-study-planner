package smartstudyplanner;

import java.awt.*;
import java.time.LocalDate;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class GUIPlanner {

    private final DefaultListModel<Task> taskListModel = new DefaultListModel<>();
    private final JTextArea outputArea = new JTextArea(16, 40);

    public static void main(String[] args) {
        // Ensure GUI created on EDT
        SwingUtilities.invokeLater(() -> new GUIPlanner().createAndShow());
    }

    private void createAndShow() {
        JFrame frame = new JFrame("Smart Study Planner - GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(10,10));
        root.setBorder(new EmptyBorder(10,10,10,10));

        // Left: task list and controls
        JPanel left = new JPanel(new BorderLayout(6,6));
        JList<Task> taskList = new JList<>(taskListModel);
        taskList.setVisibleRowCount(12);
        taskList.setFixedCellWidth(350);
        left.add(new JScrollPane(taskList), BorderLayout.CENTER);

        JPanel leftButtons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton removeBtn = new JButton("Remove Selected");
        removeBtn.addActionListener(e -> {
            int i = taskList.getSelectedIndex();
            if (i >= 0) taskListModel.remove(i);
        });
        JButton sampleBtn = new JButton("Add Sample Tasks");
        sampleBtn.addActionListener(e -> addSample());
        leftButtons.add(removeBtn);
        leftButtons.add(sampleBtn);
        left.add(leftButtons, BorderLayout.SOUTH);

        // Right: add form + generate controls + output
        JPanel right = new JPanel();
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBorder(new EmptyBorder(0,6,0,0));

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4,4,4,4);
        c.anchor = GridBagConstraints.WEST;

        int row = 0;
        c.gridx = 0; c.gridy = row; form.add(new JLabel("Title:"), c);
        JTextField titleFld = new JTextField(20);
        c.gridx = 1; form.add(titleFld, c);

        row++;
        c.gridx = 0; c.gridy = row; form.add(new JLabel("Deadline (YYYY-MM-DD):"), c);
        JTextField dlFld = new JTextField(10);
        c.gridx = 1; form.add(dlFld, c);

        row++;
        c.gridx = 0; c.gridy = row; form.add(new JLabel("Difficulty (1-5):"), c);
        SpinnerNumberModel diffModel = new SpinnerNumberModel(3, 1, 5, 1);
        JSpinner diffSpinner = new JSpinner(diffModel);
        c.gridx = 1; form.add(diffSpinner, c);

        row++;
        c.gridx = 0; c.gridy = row; form.add(new JLabel("Est hours:"), c);
        SpinnerNumberModel hoursModel = new SpinnerNumberModel(2.0, 0.1, 200.0, 0.5);
        JSpinner hoursSpinner = new JSpinner(hoursModel);
        c.gridx = 1; form.add(hoursSpinner, c);

        row++;
        c.gridx = 0; c.gridy = row; form.add(new JLabel("Start date (opt):"), c);
        JTextField startFld = new JTextField(10);
        startFld.setToolTipText("leave empty for today");
        c.gridx = 1; form.add(startFld, c);

        right.add(form);

        JPanel addRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addBtn = new JButton("Add Task");
        addBtn.addActionListener(e -> {
            String title = titleFld.getText().trim();
            if (title.isEmpty()) { JOptionPane.showMessageDialog(frame, "Title required"); return; }
            String dl = dlFld.getText().trim();
            LocalDate deadline = null;
            if (!dl.isEmpty()) {
                try { deadline = LocalDate.parse(dl); }
                catch (Exception ex) { JOptionPane.showMessageDialog(frame, "Invalid deadline format"); return; }
            }
            int diff = (Integer) diffSpinner.getValue();
            double est = ((Number) hoursSpinner.getValue()).doubleValue();
            Task t = new Task(title, deadline, diff, est);
            taskListModel.addElement(t);
            titleFld.setText("");
            dlFld.setText("");
            diffSpinner.setValue(3);
            hoursSpinner.setValue(2.0);
        });
        addRow.add(addBtn);

        JButton clearBtn = new JButton("Clear All");
        clearBtn.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(frame, "Clear all tasks?") == JOptionPane.YES_OPTION) {
                taskListModel.clear();
            }
        });
        addRow.add(clearBtn);

        right.add(addRow);

        // Plan controls
        JPanel planRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        planRow.add(new JLabel("Hours/day:"));
        SpinnerNumberModel hpd = new SpinnerNumberModel(4, 1, 24, 1);
        JSpinner hoursPerDaySpinner = new JSpinner(hpd);
        planRow.add(hoursPerDaySpinner);
        planRow.add(new JLabel("Days:"));
        SpinnerNumberModel daysModel = new SpinnerNumberModel(14, 1, 365, 1);
        JSpinner daysSpinner = new JSpinner(daysModel);
        planRow.add(daysSpinner);

        JButton planBtn = new JButton("Generate Plan");
        planBtn.addActionListener(e -> {
            int hoursPerDay = (Integer) hoursPerDaySpinner.getValue();
            int days = (Integer) daysSpinner.getValue();
            LocalDate start = LocalDate.now();
            String sdate = startFld.getText().trim();
            if (!sdate.isEmpty()) {
                try { start = LocalDate.parse(sdate); } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid start date"); return;
                }
            }
            // collect tasks
            java.util.List<Task> tasks = java.util.Collections.list(taskListModel.elements());
            if (tasks.isEmpty()) { JOptionPane.showMessageDialog(frame, "Add tasks first"); return; }
            Map<LocalDate, java.util.List<Scheduler.Slot>> plan = Scheduler.makeDailyPlan(tasks, start, hoursPerDay, days);
            outputArea.setText(Scheduler.planSummary(plan));
        });
        planRow.add(planBtn);

        right.add(planRow);

        // Output area
        outputArea.setEditable(false);
        JScrollPane outScroll = new JScrollPane(outputArea);
        outScroll.setPreferredSize(new Dimension(450, 320));
        right.add(Box.createVerticalStrut(8));
        right.add(new JLabel("Plan output:"));
        right.add(outScroll);

        // Layout
        root.add(left, BorderLayout.WEST);
        root.add(right, BorderLayout.CENTER);

        frame.getContentPane().add(root);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void addSample() {
        taskListModel.addElement(new Task("Finish topology notes", LocalDate.now().plusDays(3), 4, 3.0));
        taskListModel.addElement(new Task("Practice DSA problems", LocalDate.now().plusDays(7), 5, 5.0));
        taskListModel.addElement(new Task("Read research paper", LocalDate.now().plusDays(14), 3, 2.0));
        taskListModel.addElement(new Task("Revise lecture 4", null, 2, 1.0));
    }
}

